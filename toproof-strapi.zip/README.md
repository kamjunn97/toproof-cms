# TopRoof Strapi CMS (Deploy to Render)

This is a starter template for deploying TopRoof CMS using Strapi.

## Deployment Guide (Render)
1. Upload this project to your GitHub repo.
2. Go to https://render.com and click "New > Web Service"
3. Connect your GitHub and select this repo.
4. Use the following settings:
   - Build Command: `npm run build`
   - Start Command: `npm run start`
   - Node Version: 18
   - Add Environment Variables:
     - NODE_ENV=production
     - DATABASE_CLIENT=sqlite

5. Once deployed, access Strapi Admin at:
   `https://your-service-name.onrender.com/admin`

## Setup Locally
```bash
npm install
npm run develop
```
